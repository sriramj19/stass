# sailsmodule1

a [Sails](http://sailsjs.org) application
