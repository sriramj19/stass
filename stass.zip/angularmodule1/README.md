# angular-starter

A simple angular starter with bootstrap material design
